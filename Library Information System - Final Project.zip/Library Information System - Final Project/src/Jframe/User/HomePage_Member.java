/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Jframe.User;

import Jframe.User.Profile.MyProfile;
import Jframe.User.MyShelf.MyShelf;
import Jframe.Class.Func_Class;
import Jframe.HomePage;
import Jframe.User.BookCollection.BookCollection;
import Jframe.Class.database;
import static Jframe.User.BookCollection.BookCollection.idcolshow;
import static Jframe.User.BookCollection.BookCollection.usernameshow;
import static Jframe.User.Profile.MyProfile.addressShow;
import static Jframe.User.Profile.MyProfile.dobShow;
import static Jframe.User.Profile.MyProfile.emailShow;
import static Jframe.User.Profile.MyProfile.fullnameShow;
import static Jframe.User.Profile.MyProfile.genderShow;
import static Jframe.User.Profile.MyProfile.idprof_show;
import static Jframe.User.Profile.MyProfile.usernameShow;
import static Jframe.User.MyShelf.MyShelf.shelfID;
import static Jframe.User.MyShelf.MyShelf.shelfUsername;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.Border;

/**
 *
 * @author ais
 */
public class HomePage_Member extends javax.swing.JFrame {

    // declaring variable to store x and y value while moving
    int positionX = 0, positionY = 0;
    
    // button border
    Border buttonBorder = BorderFactory.createMatteBorder(0, 0, 1 , 0 , Color.white);
    Border buttonBorder0 = BorderFactory.createMatteBorder(1, 1, 1 , 1 , new Color (255,153,153));
    
    // create the jlables array to display the latest 5 books images
    JLabel[] labelsCover = new JLabel[5];
    
    /**
     * Creates new form HomePage_Member
     */
    
    public HomePage_Member() {
        // set the UI
        setUndecorated(true);
        initComponents();
        
        // set the frame to be in the center of the screen
        setLocationRelativeTo(null);
        
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));
        
        // call menu panel border function
        addBorders();
        
        // call display image function
        displayImage();
        
        // add border to panel header
        Border panelHeaderBorder = BorderFactory.createMatteBorder(0, 0, 1 , 0 , Color.white);
        jPanel_header.setBorder(panelHeaderBorder);
        
        // display the latest 5 books cover
        // 1 - add the jlabels to the labelsCover
        labelsCover[0] = jLabel_cover1;
        labelsCover[1] = jLabel_cover2;
        labelsCover[2] = jLabel_cover3;
        labelsCover[3] = jLabel_cover4;
        labelsCover[4] = jLabel_cover5;
        
        // call the latest book added function
        latestBookAdded(labelsCover);
    }
    
    // create a function to display image in jlabel
    public void displayImage(){
        // get the image
        ImageIcon imgicon = new ImageIcon(getClass().getResource("/MyAsset/book.png"));
        
        // make the image fit the jlabel
        Image img = imgicon.getImage().getScaledInstance(homepage_logo.getWidth(), homepage_logo.getHeight(), Image.SCALE_SMOOTH);
        
        // set the image to the jlabel
        homepage_logo.setIcon(new ImageIcon(img));
     
        // call menu panel border function
        addBorders();
        
        // call hover effect function
        buttonsHover();
    }
    
    // adding border to the menu panel button
    public void addBorders(){
        // get all component inside jpanel menu
        Component[] compss = jPanel_menu.getComponents();
        
        for(Component compp : compss)
        {
            // check if component is a button
            if(compp instanceof JButton buttonn){
                
                // add border
                buttonn.setBorder(buttonBorder0);
            }
        }            
    }
    
    // function to add a hover effect on navigation bar
    public void buttonsHover(){
       Component[] comps = jPanel_menu.getComponents();
       
       for(Component comp : comps)
       {
          // check if the component is a button
           if(comp instanceof JButton button)
           {
               
               // add the action we want to the button
               button.addMouseListener(new MouseAdapter() {
                   
                   @Override
                   public void mouseEntered(MouseEvent evt)
                   {
                       button.setBorder(buttonBorder);
                   }
                   
                   @Override
                   public void mouseExited(MouseEvent evt)
                   {
                       button.setBorder(buttonBorder0);
                   }
               });
           }
       }
    }
    
    // function to show the latest book added to the database
    public void latestBookAdded(JLabel[] labelsCover){
        
        // call the Func_Class java class
        Func_Class func = new Func_Class();
        
        ResultSet rs;
        
        try{
            // connect and fetch data from database
            java.sql.Connection conn = database.getConnection();
            String query = "SELECT book_photo FROM book_data ORDER BY time DESC LIMIT 5;" ;
            java.sql.Statement st = conn.createStatement();
            rs = st.executeQuery(query);
            
            // declare the variables to show the book images
            byte[] image;
            int i=0;
            
            // set data to target label 
            while(rs.next()){
                image = rs.getBytes("book_photo");
                func.displayImage(labelsCover[i].getWidth(), labelsCover[i].getHeight(), image, labelsCover[i]);
                i++;
            }
            
        } catch (java.sql.SQLException ex) {
            java.util.logging.Logger.getLogger(HomePage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel_menu = new javax.swing.JPanel();
        jPanel_header = new javax.swing.JPanel();
        homepage_logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jButton5 = new javax.swing.JButton();
        bookShelf = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        bookCollectionBtn = new javax.swing.JButton();
        myProfile = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        minimize_button = new javax.swing.JButton();
        exit_button = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel_cover1 = new javax.swing.JLabel();
        jLabel_cover2 = new javax.swing.JLabel();
        jLabel_cover3 = new javax.swing.JLabel();
        jLabel_cover4 = new javax.swing.JLabel();
        jLabel_cover5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel_menu.setBackground(new java.awt.Color(255, 153, 153));

        jPanel_header.setBackground(new java.awt.Color(254, 103, 110));

        jLabel1.setFont(new java.awt.Font("Lucida Fax", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Bunny Library");

        javax.swing.GroupLayout jPanel_headerLayout = new javax.swing.GroupLayout(jPanel_header);
        jPanel_header.setLayout(jPanel_headerLayout);
        jPanel_headerLayout.setHorizontalGroup(
            jPanel_headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_headerLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(homepage_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel_headerLayout.setVerticalGroup(
            jPanel_headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_headerLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_headerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(homepage_logo, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(255, 102, 102));

        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/book2.png"))); // NOI18N
        jButton5.setText("Home Page");
        jButton5.setContentAreaFilled(false);
        jButton5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton5.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jButton5.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        bookShelf.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        bookShelf.setForeground(new java.awt.Color(255, 255, 255));
        bookShelf.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/book2.png"))); // NOI18N
        bookShelf.setText("My Book Shelf");
        bookShelf.setContentAreaFilled(false);
        bookShelf.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bookShelf.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bookShelf.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        bookShelf.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookShelfMouseClicked(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Features");

        bookCollectionBtn.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        bookCollectionBtn.setForeground(new java.awt.Color(255, 255, 255));
        bookCollectionBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/book2.png"))); // NOI18N
        bookCollectionBtn.setText("Book Collection");
        bookCollectionBtn.setContentAreaFilled(false);
        bookCollectionBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bookCollectionBtn.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        bookCollectionBtn.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        bookCollectionBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bookCollectionBtnMouseClicked(evt);
            }
        });

        myProfile.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        myProfile.setForeground(new java.awt.Color(255, 255, 255));
        myProfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/winkle.png"))); // NOI18N
        myProfile.setText("My Profile");
        myProfile.setContentAreaFilled(false);
        myProfile.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        myProfile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        myProfile.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        myProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                myProfileMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel_menuLayout = new javax.swing.GroupLayout(jPanel_menu);
        jPanel_menu.setLayout(jPanel_menuLayout);
        jPanel_menuLayout.setHorizontalGroup(
            jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel_header, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_menuLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(bookShelf, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)
                        .addComponent(bookCollectionBtn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(myProfile, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 215, Short.MAX_VALUE)))
                .addGap(33, 33, 33))
        );
        jPanel_menuLayout.setVerticalGroup(
            jPanel_menuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_menuLayout.createSequentialGroup()
                .addComponent(jPanel_header, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(jLabel8)
                .addGap(36, 36, 36)
                .addComponent(bookCollectionBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bookShelf, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(myProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 16, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/moon.png"))); // NOI18N
        jLabel9.setText("Library Home Page");

        minimize_button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        minimize_button.setForeground(new java.awt.Color(255, 51, 51));
        minimize_button.setText("-");
        minimize_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                minimize_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                minimize_buttonMouseExited(evt);
            }
        });
        minimize_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimize_buttonActionPerformed(evt);
            }
        });

        exit_button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        exit_button.setForeground(new java.awt.Color(255, 51, 51));
        exit_button.setText("X");
        exit_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exit_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exit_buttonMouseExited(evt);
            }
        });
        exit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_buttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(minimize_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(exit_button)
                .addGap(9, 9, 9))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minimize_button)
                    .addComponent(exit_button)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        usernamee.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        usernamee.setForeground(new java.awt.Color(255, 51, 51));
        usernamee.setText("jLabel2");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("Hello,");

        userid.setFont(new java.awt.Font("Yu Mincho", 1, 18)); // NOI18N
        userid.setForeground(new java.awt.Color(255, 51, 51));
        userid.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userid.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/user.png"))); // NOI18N
        userid.setText("User ID :");
        userid.setMaximumSize(new java.awt.Dimension(138, 40));
        userid.setMinimumSize(new java.awt.Dimension(138, 40));

        idshow.setFont(new java.awt.Font("Yu Mincho", 1, 18)); // NOI18N
        idshow.setForeground(new java.awt.Color(255, 51, 51));
        idshow.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        idshow.setText("ID");
        idshow.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        idshow.setMaximumSize(new java.awt.Dimension(138, 40));
        idshow.setMinimumSize(new java.awt.Dimension(138, 40));

        jPanel3.setBackground(new java.awt.Color(153, 204, 255));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Latest Added Book");

        jLabel_cover1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_cover1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        jLabel_cover2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_cover2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        jLabel_cover3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_cover3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        jLabel_cover4.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_cover4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        jLabel_cover5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel_cover5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 2));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel_cover1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel_cover2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel_cover3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel_cover4, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel_cover5, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel_cover5, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                    .addComponent(jLabel_cover1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                    .addComponent(jLabel_cover2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel_cover3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel_cover4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(usernamee, javax.swing.GroupLayout.PREFERRED_SIZE, 481, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(userid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(idshow, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(userid, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(idshow, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(usernamee))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // minimize button function
    private void minimize_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_buttonMouseEntered
        // set the color when the mouse is pressed
        minimize_button.setBackground(Color.red);
        minimize_button.setForeground(Color.white);
    }//GEN-LAST:event_minimize_buttonMouseEntered

    // minimize button function
    private void minimize_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_buttonMouseExited
        // set the color when the mouse is released
        minimize_button.setBackground(new Color(255,255,255));
        minimize_button.setForeground(Color.red);
    }//GEN-LAST:event_minimize_buttonMouseExited

    // minimize button function
    private void minimize_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimize_buttonActionPerformed
        // minimize button click event
        // minimize jframe window
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimize_buttonActionPerformed

    // close button function
    private void exit_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_buttonMouseEntered
        // set the color when the mouse is pressed
        exit_button.setBackground(Color.red);
        exit_button.setForeground(Color.white);
    }//GEN-LAST:event_exit_buttonMouseEntered

    // close button function
    private void exit_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_buttonMouseExited
        // set the color when the mouse is released
        exit_button.setBackground(new Color(255,255,255));
        exit_button.setForeground(Color.red);
    }//GEN-LAST:event_exit_buttonMouseExited

    // close button function
    private void exit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_buttonActionPerformed
        dispose();
    }//GEN-LAST:event_exit_buttonActionPerformed

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        // get x and y coordinate values 
        positionX = evt.getX();
        positionY = evt.getY();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        // make jframe able to be dragged
        setLocation(evt.getXOnScreen()-positionX, evt.getYOnScreen()-positionY);
    }//GEN-LAST:event_jPanel1MouseDragged

    // Book Collection button function
    private void bookCollectionBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookCollectionBtnMouseClicked
        // declare the variables
        String id = idshow.getText();
        ResultSet rs ;
        PreparedStatement ps;
        
        // fetch data from the database
        String query = "SELECT * FROM `member` WHERE `id` = ?";
        
        try {
                // connect to the database
                ps = database.getConnection().prepareStatement(query);
                ps.setString(1, id);
                
                rs = ps.executeQuery();
                
                if(rs.next()){
                    // call book collection page
                    BookCollection book_col = new BookCollection();
                    book_col.setVisible(true);
                    
                    // set the username and id field in the page
                    usernameshow.setText(rs.getString("username"));
                    idcolshow.setText(rs.getString("id"));
        
                    // close the current page
                    this.dispose();                   
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(HomePage_Member.class.getName()).log(Level.SEVERE, null, ex);
            }
                    
    }//GEN-LAST:event_bookCollectionBtnMouseClicked

    private void bookShelfMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bookShelfMouseClicked
        // declare the variables
        String id = idshow.getText();
        ResultSet rs ;
        PreparedStatement ps;
        
        // fetch data from the database
        String query = "SELECT * FROM `member` WHERE `id` = ?";
        
        try {
                // connect to the database
                ps = database.getConnection().prepareStatement(query);
                ps.setString(1, id);
                rs = ps.executeQuery();
                
                if(rs.next()){ 
                    
                    // Call book shelf page
                    MyShelf myshelf = new MyShelf();
                    myshelf.setVisible(true);
                    
                    // set the username and id field in the page
                    shelfUsername.setText(rs.getString("username"));
                    shelfID.setText(rs.getString("id"));
                    
                    // close the current page
                    this.dispose();                    
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(HomePage_Member.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bookShelfMouseClicked

    private void myProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_myProfileMouseClicked
        // declare the variables
        String id = idshow.getText();
        ResultSet rs ;
        PreparedStatement ps;
        
        // fetch data from the database
        String query = "SELECT * FROM `member` WHERE `id` = ?";
        
        try {
                // connect to the database
                ps = database.getConnection().prepareStatement(query);
                ps.setString(1, id);
                rs = ps.executeQuery();
                
                if(rs.next()){
                    
                    // call my profile page
                    MyProfile myprofile = new MyProfile();
                    myprofile.setVisible(true);
                    
                    // set data to target text fields
                    idprof_show.setText(rs.getString("id"));
                    fullnameShow.setText(rs.getString("fullName"));
                    genderShow.setText(rs.getString("gender"));
                    dobShow.setText(rs.getString("dob"));
                    addressShow.setText(rs.getString("address"));
                    usernameShow.setText(rs.getString("username"));
                    emailShow.setText(rs.getString("email"));
                    
                    // close the current page
                    this.dispose();                    
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(HomePage_Member.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_myProfileMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePage_Member.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePage_Member.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePage_Member.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePage_Member.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePage_Member().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bookCollectionBtn;
    private javax.swing.JButton bookShelf;
    private javax.swing.JButton exit_button;
    private javax.swing.JLabel homepage_logo;
    public static final javax.swing.JLabel idshow = new javax.swing.JLabel();
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_cover1;
    private javax.swing.JLabel jLabel_cover2;
    private javax.swing.JLabel jLabel_cover3;
    private javax.swing.JLabel jLabel_cover4;
    private javax.swing.JLabel jLabel_cover5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel_header;
    private javax.swing.JPanel jPanel_menu;
    private javax.swing.JButton minimize_button;
    private javax.swing.JButton myProfile;
    public static final javax.swing.JLabel userid = new javax.swing.JLabel();
    public static final javax.swing.JLabel usernamee = new javax.swing.JLabel();
    // End of variables declaration//GEN-END:variables
}
