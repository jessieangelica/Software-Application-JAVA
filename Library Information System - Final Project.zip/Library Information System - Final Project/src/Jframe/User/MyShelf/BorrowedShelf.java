/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Jframe.User.MyShelf;

import Jframe.Class.MultiLineJTable;
import Jframe.User.BookCollection.BookCollection;
import Jframe.Class.database;
import Jframe.User.HomePage_Member;
import static Jframe.User.MyShelf.MyShelf.shelfID;
import static Jframe.User.MyShelf.MyShelf.shelfUsername;
import static Jframe.User.MyShelf.ReturnBook.bookID_show;
import static Jframe.User.MyShelf.ReturnBook.borrid_show;
import static Jframe.User.MyShelf.ReturnBook.borrowdate_show;
import static Jframe.User.MyShelf.ReturnBook.fineShow;
import static Jframe.User.MyShelf.ReturnBook.membID_show;
import static Jframe.User.MyShelf.ReturnBook.returndate_show;
import static Jframe.User.MyShelf.ReturnBook.title_show;
import static Jframe.User.MyShelf.ReturnBook.today_show;
import static Jframe.User.MyShelf.ReturnBook.user_show;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import static Jframe.User.MyShelf.BorrowedMoreDetails.membid_detail;
import static Jframe.User.MyShelf.BorrowedMoreDetails.username_detail;

/**
 *
 * @author ais
 */
public class BorrowedShelf extends javax.swing.JFrame {

    /**
     * Creates new form BorrowedShelf
     */
    
    // provides a table model for JTable components
    DefaultTableModel model;
    
    // declaring variable to store x and y value while moving
    int positionX = 0, positionY = 0;
    
    public BorrowedShelf() {
        // set the UI
        setUndecorated(true);
        initComponents();
        
        // set the frame to be in the center of the screen
        setLocationRelativeTo(null);
        
        setShape(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 20, 20));
        
        // allow us to modify the properties of the header
        JTableHeader tableHeader = borrow_table.getTableHeader();
        
        // set the foreground color of the header to red
        tableHeader.setForeground(Color.red); 
    }
    
    // function to show the borrowed book details to the table
    public void setBorrowDetailsToTable(){
        // declare the variables
        String field = idborshow.getText();
        String status = "ISSUED";
        
        try{
            // connect and fetch data from database
            Connection conn = database.getConnection();
            String query = "SELECT * FROM borrow_book WHERE member_id = '"+field+"' AND status = '"+status+"'";
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(query);
            
            // set data to target table
            while (rs.next()){
                int borrowid = rs.getInt("borrow_id");
                String bookid = rs.getString("book_id");
                String booktitle = rs.getString("book_title");
                Date borrow_date = rs.getDate("borrow_date");
                String return_date = rs.getString("return_date");
                
                Object[] obj = {borrowid, bookid, booktitle, borrow_date, return_date};
                model = (DefaultTableModel)borrow_table.getModel();
                model.addRow(obj);
                borrow_table.setShowVerticalLines(true);
                borrow_table.setShowHorizontalLines(true);
                
            }
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        MultiLineJTable renderer = new MultiLineJTable();
        
        //set table cell renderer into a specified JTable column class
        borrow_table.setDefaultRenderer(String[].class, renderer);
        
    }
    
    // function to show the amount of fine 
    public void showFine() {
        try {
            // set data to target table
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
            Date borrowdate = borrowdate_show.getDate();
            Date returndate = returndate_show.getDate();
            Date todaydate = today_show.getDate();
            
            // get the value between two dates
            long diffInMillies = Math.abs(returndate.getTime() - borrowdate.getTime());
            long diffInMilliess = Math.abs(todaydate.getTime() - borrowdate.getTime());
            long limitDiff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
            long diff = TimeUnit.DAYS.convert(diffInMilliess, TimeUnit.MILLISECONDS);
            
            // convert long to int value
            int limDiff = Math.toIntExact(limitDiff);
            int daysDiff = Math.toIntExact(diff);
            int totalFine;
            
            // amount of fine charge to the user per day
            int finePerDay = 50000;
           
            // if return the book before the given due date, which is 3 days, no fine will be charge
            if (daysDiff <= 3) {
                totalFine = 0;
                fineShow.setText(String.valueOf(totalFine));
            
            // if return the book after the given due date, which is 3 days, the fine will be charge per how many days late
            } else if (daysDiff > 3) {
                totalFine = (daysDiff - limDiff) * finePerDay;
                fineShow.setText(String.valueOf(totalFine));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        minimize_button = new javax.swing.JButton();
        exit_button = new javax.swing.JButton();
        back_button = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        borrow_table = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        returnBookBtn = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        retdate_show = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        borrowid_show = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        booktitle_show = new javax.swing.JTextArea();
        showMoreBtn = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        showBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(102, 102, 255));
        jPanel1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel1MouseDragged(evt);
            }
        });
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel1MousePressed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));

        minimize_button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        minimize_button.setForeground(new java.awt.Color(255, 51, 51));
        minimize_button.setText("-");
        minimize_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                minimize_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                minimize_buttonMouseExited(evt);
            }
        });
        minimize_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minimize_buttonActionPerformed(evt);
            }
        });

        exit_button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        exit_button.setForeground(new java.awt.Color(255, 51, 51));
        exit_button.setText("X");
        exit_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exit_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exit_buttonMouseExited(evt);
            }
        });
        exit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_buttonActionPerformed(evt);
            }
        });

        back_button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_button.setForeground(new java.awt.Color(255, 51, 51));
        back_button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/back.png"))); // NOI18N
        back_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                back_buttonMouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Book Antiqua", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/moon.png"))); // NOI18N
        jLabel9.setText("My Shelf - Borrowed Book Data");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(back_button, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(minimize_button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(exit_button)
                .addGap(9, 9, 9))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minimize_button)
                    .addComponent(exit_button)
                    .addComponent(back_button))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(8, 8, 8))
        );

        borrow_table.setBackground(new java.awt.Color(255, 204, 204));
        borrow_table.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        borrow_table.setForeground(new java.awt.Color(255, 255, 255));
        borrow_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Borrow ID", "Book ID", "Book Title", "Borrow Date", "Return Due Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        borrow_table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        borrow_table.setGridColor(new java.awt.Color(255, 255, 255));
        borrow_table.setRowHeight(50);
        borrow_table.setSelectionBackground(new java.awt.Color(255, 153, 153));
        borrow_table.setSelectionForeground(new java.awt.Color(255, 255, 255));
        borrow_table.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        borrow_table.setShowGrid(true);
        borrow_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                borrow_tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(borrow_table);
        if (borrow_table.getColumnModel().getColumnCount() > 0) {
            borrow_table.getColumnModel().getColumn(0).setMinWidth(80);
            borrow_table.getColumnModel().getColumn(0).setMaxWidth(80);
            borrow_table.getColumnModel().getColumn(1).setMinWidth(90);
            borrow_table.getColumnModel().getColumn(1).setMaxWidth(90);
            borrow_table.getColumnModel().getColumn(2).setMinWidth(400);
            borrow_table.getColumnModel().getColumn(2).setMaxWidth(400);
            borrow_table.getColumnModel().getColumn(3).setMinWidth(100);
            borrow_table.getColumnModel().getColumn(3).setMaxWidth(100);
        }

        jPanel3.setBackground(new java.awt.Color(226, 241, 247));

        returnBookBtn.setFont(new java.awt.Font("STFangsong", 1, 14)); // NOI18N
        returnBookBtn.setForeground(new java.awt.Color(255, 0, 0));
        returnBookBtn.setText("Return Book");
        returnBookBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                returnBookBtnMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 102, 102));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/borrowbook.png"))); // NOI18N
        jLabel10.setText("Borrowing Details");

        retdate_show.setEditable(false);

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 102, 102));
        jLabel16.setText("Return Due Date");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 102, 102));
        jLabel15.setText("Borrow Date");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 102, 102));
        jLabel14.setText("Book Title");

        bordate_show.setEditable(false);

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 102, 102));
        jLabel17.setText("Book ID");

        bookid_show.setEditable(false);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 102, 102));
        jLabel13.setText("Borrow ID");

        borrowid_show.setEditable(false);

        booktitle_show.setEditable(false);
        booktitle_show.setColumns(20);
        booktitle_show.setLineWrap(true);
        booktitle_show.setRows(5);
        booktitle_show.setAutoscrolls(false);
        jScrollPane1.setViewportView(booktitle_show);

        showMoreBtn.setFont(new java.awt.Font("STFangsong", 1, 14)); // NOI18N
        showMoreBtn.setForeground(new java.awt.Color(255, 0, 0));
        showMoreBtn.setText("Show More Details");
        showMoreBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showMoreBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bookid_show, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(borrowid_show)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel16)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bordate_show, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                            .addComponent(retdate_show))))
                .addGap(19, 19, 19))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jLabel10)
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(returnBookBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(99, 99, 99))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(showMoreBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(80, 80, 80))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(jLabel10)
                .addGap(50, 50, 50)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(borrowid_show, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bookid_show, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bordate_show, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(retdate_show, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addComponent(returnBookBtn)
                .addGap(18, 18, 18)
                .addComponent(showMoreBtn)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        unameshow.setFont(new java.awt.Font("Yu Mincho", 1, 18)); // NOI18N
        unameshow.setForeground(new java.awt.Color(255, 51, 51));
        unameshow.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        unameshow.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MyAsset/user.png"))); // NOI18N
        unameshow.setText("Username");
        unameshow.setMaximumSize(new java.awt.Dimension(138, 40));
        unameshow.setMinimumSize(new java.awt.Dimension(138, 40));

        idborshow.setEditable(false);
        idborshow.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Yu Mincho", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 51));
        jLabel2.setText("User ID :");
        jLabel2.setMaximumSize(new java.awt.Dimension(138, 40));
        jLabel2.setMinimumSize(new java.awt.Dimension(138, 40));

        showBtn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        showBtn.setForeground(new java.awt.Color(255, 102, 102));
        showBtn.setText("Show");
        showBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showBtnMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idborshow, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(showBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(unameshow, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 806, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(idborshow, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(unameshow, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(showBtn))
                        .addGap(29, 29, 29)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 472, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MousePressed
        // get x and y coordinate values
        positionX = evt.getX();
        positionY = evt.getY();
    }//GEN-LAST:event_jPanel1MousePressed

    private void jPanel1MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseDragged
        // make jframe able to be dragged
        setLocation(evt.getXOnScreen()-positionX, evt.getYOnScreen()-positionY);
    }//GEN-LAST:event_jPanel1MouseDragged
    
    // function to show the chosen row of borrowed book details from the table
    private void borrow_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_borrow_tableMouseClicked
        // set data to target table
        int rowNo = borrow_table.getSelectedRow();
        TableModel model = borrow_table.getModel();
        
        // get value from the chosen row and columns
        String borrowid = model.getValueAt(rowNo, 0).toString();
        String bookid = model.getValueAt(rowNo, 1).toString();
        String booktitle = model.getValueAt(rowNo, 2).toString();
        String bordate = model.getValueAt(rowNo, 3).toString();
        String retdate = model.getValueAt(rowNo, 4).toString();
        
        // set the chosen value from the table to the text field
        borrowid_show.setText(borrowid);
        bookid_show.setText(bookid);
        booktitle_show.setText(booktitle);
        bordate_show.setText(bordate);
        retdate_show.setText(retdate);

    }//GEN-LAST:event_borrow_tableMouseClicked

    // event function to go back to the previous page
    private void back_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_back_buttonMouseClicked
        // declare the variables
        String id = idborshow.getText();
        ResultSet rs ;
        PreparedStatement ps;
        
        // fetch data from database
        String query = "SELECT * FROM `member` WHERE `id` = ?";
        
        try {
                // connect to the database
                ps = database.getConnection().prepareStatement(query);
                ps.setString(1, id);
                
                rs = ps.executeQuery();
                
                if(rs.next()){
                    // call the book shelf page
                    MyShelf myshelf = new MyShelf();
                    myshelf.setVisible(true);
                    
                    // set the username and id field in the page
                    shelfUsername.setText(rs.getString("username"));
                    shelfID.setText(rs.getString("id"));
        
                    // close the current page
                    this.dispose();
                    
                }
            } catch (java.sql.SQLException ex) {
                Logger.getLogger(HomePage_Member.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//GEN-LAST:event_back_buttonMouseClicked

    // close button function
    private void exit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_buttonActionPerformed
        dispose();
    }//GEN-LAST:event_exit_buttonActionPerformed

    // close button function
    private void exit_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_buttonMouseExited
        // set the color when the mouse is released
        exit_button.setBackground(new Color(255,255,255));
        exit_button.setForeground(Color.red);
    }//GEN-LAST:event_exit_buttonMouseExited

    // close button function
    private void exit_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exit_buttonMouseEntered
        // set the color when the mouse is pressed
        exit_button.setBackground(Color.red);
        exit_button.setForeground(Color.white);
    }//GEN-LAST:event_exit_buttonMouseEntered

    // minimize button function
    private void minimize_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minimize_buttonActionPerformed
        // minimize button click event
        // minimize jframe window
        setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_minimize_buttonActionPerformed

    // minimize button function
    private void minimize_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_buttonMouseExited
        // set the color when the mouse is released
        minimize_button.setBackground(new Color(255,255,255));
        minimize_button.setForeground(Color.red);
    }//GEN-LAST:event_minimize_buttonMouseExited

    // minimize button function
    private void minimize_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimize_buttonMouseEntered
        // set the color when the mouse is pressed
        minimize_button.setBackground(Color.red);
        minimize_button.setForeground(Color.white);
    }//GEN-LAST:event_minimize_buttonMouseEntered

    private void showBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showBtnMouseClicked
        // call the function to show the borrowed book details
        setBorrowDetailsToTable();
    }//GEN-LAST:event_showBtnMouseClicked

    // click event function to go to the return book page
    private void returnBookBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_returnBookBtnMouseClicked
        // declare the variables
        String borrowID = borrowid_show.getText();

        // if the text field of borrow id is empty then cannot proceed
        if(borrowID.trim().equals("")){
            JOptionPane.showMessageDialog(null, "Please choose a book you want to return", "Warning", 2);
        } else {
            ResultSet rs ;
            PreparedStatement ps;
            
            // fetch data from database
            String query = "SELECT * FROM `borrow_book` WHERE `borrow_id` = ?";

            try {
                    // connect to the database
                    ps = database.getConnection().prepareStatement(query);
                    ps.setString(1, borrowID);
                    rs = ps.executeQuery();

                    if(rs.next()){ 
                        // call the return book page
                        new ReturnBook().setVisible(true);
                        
                        // set data to target text field
                        String bookid = rs.getString("book_id");
                        int memberid = rs.getInt("member_id");
                        String member_id = Integer.toString(memberid);
                        String booktitle = rs.getString("book_title");
                        Date borrow_date = rs.getDate("borrow_date");
                        Date return_date = rs.getDate("return_date");
                        String username = rs.getString("username");
                        
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); 
                        Date date = new Date(); 
                        today_show.setDate(date);
                        
                        borrid_show.setText(borrowID);
                        bookID_show.setText(bookid);
                        membID_show.setText(member_id);
                        title_show.setText(booktitle);
                        borrowdate_show.setDate(borrow_date);
                        returndate_show.setDate(return_date);
                        user_show.setText(username);
                        
                        showFine();

                        // close the current page
                        this.dispose();

                    }
                } catch (java.sql.SQLException ex) {
                    Logger.getLogger(BookCollection.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_returnBookBtnMouseClicked

    // event function to show more details of the borrowed book
    private void showMoreBtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showMoreBtnMouseClicked
        // declare the variable
        String txtBookId = bookid_show.getText();
        
        if(txtBookId.trim().equals("")){ // if the book id text field is empty
            JOptionPane.showMessageDialog(null, "Please choose a book you want to borrow", "Warning", 2);
        } else {
            // declare the variables
            String id = idborshow.getText();
            ResultSet rs ;
            PreparedStatement ps;
            
            // fetch data from database
            String query = "SELECT * FROM `member` WHERE `id` = ?";

            try {
                    // connect to the database
                    ps = database.getConnection().prepareStatement(query);
                    ps.setString(1, id);
                    rs = ps.executeQuery();

                    if(rs.next()){ 
                        // call the borrowed book details page
                        new BorrowedMoreDetails(txtBookId).setVisible(true);
                        
                        // set the username and id field in the page
                        username_detail.setText(rs.getString("username"));
                        membid_detail.setText(rs.getString("id"));

                        //close the current page
                        this.dispose();

                    }
                } catch (java.sql.SQLException ex) {
                    Logger.getLogger(BookCollection.class.getName()).log(Level.SEVERE, null, ex);
                }
        }
    }//GEN-LAST:event_showMoreBtnMouseClicked
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BorrowedShelf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BorrowedShelf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BorrowedShelf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BorrowedShelf.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BorrowedShelf().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_button;
    public static final javax.swing.JTextField bookid_show = new javax.swing.JTextField();
    private javax.swing.JTextArea booktitle_show;
    public static final javax.swing.JTextField bordate_show = new javax.swing.JTextField();
    private javax.swing.JTable borrow_table;
    private javax.swing.JTextField borrowid_show;
    private javax.swing.JButton exit_button;
    public static final javax.swing.JTextField idborshow = new javax.swing.JTextField();
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel9;
    public static final javax.swing.JPanel jPanel1 = new javax.swing.JPanel();
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton minimize_button;
    private javax.swing.JTextField retdate_show;
    private javax.swing.JButton returnBookBtn;
    private javax.swing.JButton showBtn;
    private javax.swing.JButton showMoreBtn;
    public static final javax.swing.JLabel unameshow = new javax.swing.JLabel();
    // End of variables declaration//GEN-END:variables
    
    // display an image stored as a byte array in a JTable cell using a JLabel component
    private static class ImageRender extends DefaultTableCellRenderer {

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel jlabel = new JLabel();
            byte[] bytes = (byte[]) value;
            ImageIcon imageIcon = new ImageIcon(
                    new ImageIcon(bytes).getImage().getScaledInstance(165, 280, Image.SCALE_DEFAULT)
            );
            jlabel.setIcon(imageIcon);
            return jlabel;
        }
    }

}


